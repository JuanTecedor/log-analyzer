```
head access.log > access-small.log
grep "10.105.21.199" logs/access.log | wc -l
```
